import static javax.swing.JOptionPane.*;

public class Viewparking extends Area{
    String Slot;

    public String defence(){
        Slot = showInputDialog(
                """
                        AVAILABLE SLOTS
                         1. A1
                         2. A2
                         3. A3
                       
                        """
        );
        return (Slot);
    }


    public String saddar(){
        Slot = showInputDialog(
                """
                        AVAILABLE SLOTS
                         1. B1
                         2. B2
                         3. B3
                        """
        );
        return (Slot);
    }
    public String fbarea(){
        Slot = showInputDialog(
                """
                        AVAILABLE SLOTS
                         1. C1
                         2. C2
                         3. C3
                        """
        );
        return (Slot);
    }
    public String clifton(){
        Slot = showInputDialog(
                """
                        AVAILABLE SLOTS
                         1. A1
                         2. C3
                         3. B2
                        """
        );
        return (Slot);
    }
    public String gulshan(){
        Slot = showInputDialog(
                """
                        AVAILABLE SLOTS
                         1. A1
                         2. B2
                         3. D3
                        """
        );
        return (Slot);
    }


}
