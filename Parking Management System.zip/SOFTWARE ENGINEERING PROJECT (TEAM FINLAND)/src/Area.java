import javax.swing.*;
//parent class
public class Area {

    public void DisplayMenu(){

        String menu;
        menu = JOptionPane.showInputDialog(
                """
                        AREAS FOR PARKING
                         1. DEFENCE
                         2. SADDAR
                         3. GULSHAN
                         4. FB AREA
                         5. CLIFTON
                        """
        );
        switch (menu) {
            case "defence" -> {
                AVAILABLESLOTS();
            }
            case "saddar" -> {
                AVAILABLESLOTS();
            }
            case "gulshan" -> {

                AVAILABLESLOTS();
            }
            case "fb area" -> {
                AVAILABLESLOTS();
            }
            case "clifton" -> {
                AVAILABLESLOTS();
            }
        }
    }
    public void AVAILABLESLOTS(){
        JOptionPane.showMessageDialog(null, "VIEW AVAILABLE PARKINGS", "PARKINGS", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "\n" +
                "                      AVAILABLE SLOTS\n" +
                "                      1. A2\n" +
                "                      2. B1\n" +
                "                      3. B2\n" +
                "                        ");
        JOptionPane.showConfirmDialog(null, "RETURN TO MENU");
    }

    public void returnmenu(){
        System.out.println("\t\t\t\t\t\t               press 1 to return to menu");
    }
}
